﻿namespace Numerics
  module Numeric =

    let add (aX1,aX2) = aX1 + aX2
    let subtract (aX1,aX2) = aX1 - aX2