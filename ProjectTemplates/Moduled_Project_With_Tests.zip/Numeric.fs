﻿module Numeric

let add (aX1,aX2) = aX1 + aX2
