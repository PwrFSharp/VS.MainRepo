﻿namespace BT
  module Tuples=

  let third (aX1,aX2,aX3) = aX3

  let sumAll (aX1:float,aX2:float,aX3:float,aX4:float) =
    aX1+aX2+aX3+aX4



